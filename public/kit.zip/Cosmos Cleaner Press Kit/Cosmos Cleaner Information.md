----------=----------=----------

# Cosmos Cleaner Press/Media Kit and Information about Cosmos Cleaner
*Last Updated: November 16, 2023*

----------=----------=----------

## Cosmos Cleaner Info

### Name:
- Cosmos Cleaner

### Short Description:
- Clean up space junk, upgrade your ship, and become the best cleaner in the cosmos!

### Links:
- Official Website: [CosmosCleaner.com](https://CosmosCleaner.com "Visit the game website for Cosmos Cleaner at CosmosCleaner.com")
- Official Wiki: [Wiki.CosmosCleaner.com](https://Wiki.CosmosCleaner.com "Visit the game website for Cosmos Cleaner at Wiki.CosmosCleaner.com")
- Game Privacy Policy: [CosmosCleaner.com/privacygame](https://CosmosCleaner.com/privacygame "Visit the privacy policy for Cosmos Cleaner at CosmosCleaner.com/privacygame")
- Website/Wiki Privacy Policy: [CosmosCleaner.com/privacy](https://CosmosCleaner.com/privacy "Visit the privacy policy for Cosmos Cleaner's Website and Wiki at CosmosCleaner.com/privacy")
- Game Terms of Service: [CosmosCleaner.com/tosgame](https://CosmosCleaner.com/tosgame "Visit the terms of service for Cosmos Cleaner at CosmosCleaner.com/tosgame")
- Website/Wiki Terms of Service: [CosmosCleaner.com/tos](https://CosmosCleaner.com/tos "Visit the terms of service for Cosmos Cleaner's Website and Wiki at CosmosCleaner.com/tos")
- Copyright/License Information: [CosmosCleaner.com/copyright](https://CosmosCleaner.com/copyright "View the copyright information for Cosmos Cleaner at CosmosCleaner.com/copyright")
- Game By: [Derek Perry - derek-perry.com](https://derek-perry.com "Go to Derek Perry, the creator of Cosmos Cleaner, at derek-perry.com")
- Game GitHub: [github.com/derek-perry/CosmosCleaner](https://github.com/derek-perry/CosmosCleaner "Visit the GitHub for Cosmos Cleaner at github.com/derek-perry/CosmosCleaner")
- Website GitHub: [github.com/derek-perry/cosmoscleaner.com](https://github.com/derek-perry/cosmoscleaner.com "Visit the GitHub for Cosmos Cleaner's Website at github.com/derek-perry/cosmoscleaner.com")
- Wiki GitHub: [github.com/derek-perry/wiki.cosmoscleaner.com](https://github.com/derek-perry/wiki.cosmoscleaner.com "Visit the GitHub for Cosmos Cleaner's Wiki at github.com/derek-perry/wiki.cosmoscleaner.com")

### Social Media:
- **X (formerly Twitter):** [x.com/CosmosCleaner](https://x.com/CosmosCleaner "Visit the X (formerly Twitter) for Cosmos Cleaner at twitter.com/CosmosCleaner")
- **Facebook:** [facebook.com/CosmosCleaner](https://facebook.com/CosmosCleaner "Visit the Facebook for Cosmos Cleaner at facebook.com/CosmosCleaner")
- **Instagram:** [instagram.com/CosmosCleaner](https://instagram.com/CosmosCleaner "Visit the Instagram for Cosmos Cleaner at instagram.com/CosmosCleaner")
- **Threads:** [threads.net/CosmosCleaner](https://threads.net/@CosmosCleaner "Visit the Threads for Cosmos Cleaner at threads.net/CosmosCleaner")
- **YouTube:** [youtube.com/@CosmosCleaner](https://youtube.com/@CosmosCleaner "Visit the YouTube for Cosmos Cleaner at youtube.com/@CosmosCleaner")
- **Reddit:** [reddit.com/r/CosmosCleaner](https://reddit.com/r/CosmosCleaner "Visit the Reddit for Cosmos Cleaner at reddit.com/r/CosmosCleaner")
- **Discord:** [discord.gg/sncuXN5n2q](https://discord.gg/sncuXN5n2q "Join the Discord for Cosmos Cleaner at discord.gg/sncuXN5n2q")

### Primary Contact:
- Contact@CosmosCleaner.com

### Developer:
- Derek Perry, dp@derek-perry.com, [derek-perry.com](https://derek-perry.com "Go to Derek Perry, the developer of Cosmos Cleaner, at derek-perry.com")

### Platform Information:
- Windows 10/Windows 11 Direct Download [CosmosCleaner.com/play](https://CosmosCleaner.com/play "Download and Play Cosmos Cleaner on Windows 10 or 11 at CosmosCleaner.com/play")
- Mac (Planned)
- Linux (Planned)
- Android (Planned)
- iOS (Planned)

### Price:
- Free

### Game Made Using:
- Unreal Engine 5.3.2
- Adobe Photoshop
- Adobe Illustrator

### Website Made Using:
- Next.js
- Typescript
- Tailwind CSS
- Netlify
- Adobe Photoshop
- Adobe Illustrator

### Wiki Made Using:
- MkDocs
- Netlify
- Adobe Photoshop
- Adobe Illustrator

----------=----------=----------

## Cosmos Cleaner Branding

### Fonts:
- [Bai Jamjuree](https://github.com/cadsondemak/Bai-Jamjuree "View Bai Jamjuree on GitHub")
	- By [Cadson Demak](https://github.com/cadsondemak "Go to Cadson Demak, the Creator of Bai Jamjuree, on GitHub") ([SIL Open Font License 1.1](https://scripts.sil.org/ofl" "View the Official SIL Open Font License 1.1 at scripts.sil.org/ofl")) Copyright 2008
	- Google Fonts Link: [fonts.google.com/specimen/Bai+Jamjuree](https://fonts.google.com/specimen/Bai+Jamjuree "View Bai Jamjuree on Google Fonts")
	- Paragraph Text
	- Heading Text
	- Used in:
		- Logo Text "Cosmos"
		- Website Paragraph Text
		- Website Heading Text
		- Game Paragraph Text
		- Game Heading Text
- [Sonsie One](http://www.rdftype.it/?/projects/sonsie/ "View Sonsie One of Riccardo De Franceschi's Website")
	- By [Riccardo De Franceschi](http://www.rdftype.it "Go to Riccardo De Franceschi, the Creator of Sonsie One, at www.rdftype.it") ([SIL Open Font License 1.1](https://scripts.sil.org/ofl" "View the Official SIL Open Font License 1.1 at scripts.sil.org/ofl")) Copyright 2011
	- Google Fonts Link: [fonts.google.com/specimen/Sonsie+One](https://fonts.google.com/specimen/Sonsie+One "View Sonsie One on Google Fonts")
	- Display Text
	- Used in:
		- Logo Text "Cleaner"

### Colors:
- Green Accent
	- Classifications
		- TailwindCSS: Lime-500
		- HEX: #84cc16
		- RGB: 132, 204, 22
		- CMYK: 35%, 0%, 89%, 20%
		- HSV: 83°, 89%, 80%
		- HSL: 83°, 81%, 44%
- Blue Accent
	- Classifications
		- TailwindCSS: Sky-500
		- HEX: #0ea5e9
		- RGB: 14, 165, 233
		- CMYK: 94%, 29%, 0%, 9%
		- HSV: 198°, 94%, 91%
		- HSL: 198°, 89%, 48%
- Main Blue Background
	- Classifications
		- TailwindCSS: Blue-900
		- HEX: #1e3a8a
		- RGB: 30, 58, 138
		- CMYK: 78%, 58%, 0%, 46%
		- HSV: 224°, 78%, 54%
		- HSL: 224°, 64%, 33%
- Light Blue Background
	- Classifications
		- TailwindCSS: Cyan-100
		- HEX: #cffafe
		- RGB: 207, 250, 254
		- CMYK: 19%, 2%, 0%, 0%
		- HSV: 186°, 19%, 100%
		- HSL: 186°, 100%, 91%
- Dark Blue Background
	- Classifications
		- TailwindCSS: Cyan-900
		- HEX: #164e63
		- RGB: 22, 78, 99
		- CMYK: 78%, 21%, 0%, 61%
		- HSV: 196°, 78%, 39%
		- HSL: 196°, 64%, 24%

----------=----------=----------